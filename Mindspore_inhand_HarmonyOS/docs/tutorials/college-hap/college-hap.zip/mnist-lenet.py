# -*- coding: utf-8 -*-
"""MindSpore + MNIST + LeNet5 手写数字识别：训练、评估、导出与回载验证。

用法：
    python mnist-lenet.py --epochs 5 --batch-size 32 --learning-rate 0.01 \
        --data-dir data/MNIST --output-dir artifacts
"""
import argparse
import os
import time

import numpy as np

import mindspore as ms
from mindspore import Tensor, dataset as ds, nn
import mindspore.dataset.transforms as transforms
import mindspore.dataset.vision as vision


def build_dataset(data_dir, usage, batch_size, shuffle):
    """读取 MNIST IDX 文件，做归一化并打包成 batch。"""
    dataset = ds.MnistDataset(data_dir, usage=usage, shuffle=shuffle)
    dataset = dataset.map(vision.Rescale(1.0 / 255.0, 0), input_columns="image")
    dataset = dataset.map(
        vision.Normalize(mean=[0.1307], std=[0.3081]), input_columns="image"
    )
    dataset = dataset.map(vision.HWC2CHW(), input_columns="image")
    dataset = dataset.map(
        transforms.TypeCast(ms.int32), input_columns="label"
    )
    return dataset.batch(batch_size, drop_remainder=False)


class LeNet5(nn.Cell):
    """现代 LeNet-5 风格：两组卷积+ReLU+最大池化，后接三层全连接。"""

    def __init__(self, num_class=10):
        super().__init__()
        self.features = nn.SequentialCell(
            nn.Conv2d(1, 6, 5, pad_mode="valid"), nn.ReLU(), nn.MaxPool2d(2, 2),
            nn.Conv2d(6, 16, 5, pad_mode="valid"), nn.ReLU(), nn.MaxPool2d(2, 2),
        )
        self.classifier = nn.SequentialCell(
            nn.Flatten(),
            nn.Dense(16 * 4 * 4, 120), nn.ReLU(),
            nn.Dense(120, 84), nn.ReLU(),
            nn.Dense(84, num_class),
        )

    def construct(self, x):
        return self.classifier(self.features(x))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=0.01)
    parser.add_argument("--data-dir", default="data/MNIST")
    parser.add_argument("--output-dir", default="artifacts")
    args = parser.parse_args()

    ms.set_context(mode=ms.GRAPH_MODE, device_target="CPU")
    ms.set_seed(42)

    train_data = build_dataset(args.data_dir, "train", args.batch_size, shuffle=True)
    test_data = build_dataset(args.data_dir, "test", args.batch_size, shuffle=False)

    network = LeNet5()
    total_params = sum(p.size for p in network.trainable_params())
    print(f"trainable_params={total_params}")

    loss_fn = nn.SoftmaxCrossEntropyWithLogits(sparse=True, reduction="mean")
    optimizer = nn.Momentum(
        network.trainable_params(), learning_rate=args.learning_rate, momentum=0.9
    )
    model = ms.Model(
        network, loss_fn=loss_fn, optimizer=optimizer,
        metrics={"accuracy": nn.Accuracy()},
    )

    os.makedirs(args.output_dir, exist_ok=True)
    best_acc = 0.0
    t_start = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        t0 = time.perf_counter()
        model.train(1, train_data, dataset_sink_mode=False)
        metrics = model.eval(test_data, dataset_sink_mode=False)
        acc = metrics["accuracy"]
        best_acc = max(best_acc, acc)
        print(
            f"epoch={epoch:02d} test_accuracy={acc:.4f} "
            f"seconds={time.perf_counter() - t0:.3f}",
            flush=True,
        )
    total_seconds = time.perf_counter() - t_start
    print(f"final_accuracy={acc:.4f} best_accuracy={best_acc:.4f} "
          f"total_seconds={total_seconds:.3f}")

    # 保存权重并导出 MindIR
    ckpt_path = os.path.join(args.output_dir, "lenet_mnist.ckpt")
    ms.save_checkpoint(network, ckpt_path)
    ms.export(
        network,
        Tensor(np.zeros((1, 1, 28, 28), np.float32)),
        file_name=os.path.join(args.output_dir, "lenet_mnist"),
        file_format="MINDIR",
    )

    # 回载 MindIR，和训练中的网络对同一张图做交叉验证
    graph_network = nn.GraphCell(
        ms.load(os.path.join(args.output_dir, "lenet_mnist.mindir"))
    )
    for sample, label in test_data.create_tuple_iterator(output_numpy=True):
        image, label = sample[:1], int(label[0])
        break
    logits_train = network(Tensor(image)).asnumpy()
    logits_export = graph_network(Tensor(image)).asnumpy()
    diff = float(np.abs(logits_train - logits_export).max())
    print(f"sample_label={label} pred_train={int(logits_train.argmax())} "
          f"pred_export={int(logits_export.argmax())} max_abs_diff={diff}")

    for name in ("lenet_mnist.ckpt", "lenet_mnist.mindir"):
        path = os.path.join(args.output_dir, name)
        print(f"artifact={name} bytes={os.path.getsize(path)}")


if __name__ == "__main__":
    main()
